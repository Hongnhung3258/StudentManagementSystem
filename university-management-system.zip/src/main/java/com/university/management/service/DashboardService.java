package com.university.management.service;

import java.util.Map;

public interface DashboardService {
    Map<String, Long> getStatistics();
}